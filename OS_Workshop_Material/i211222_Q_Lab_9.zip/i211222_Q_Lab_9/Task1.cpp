#include <unistd.h>
#include <iostream>
#include <sys/wait.h>
#include <sys/stat.h>
using namespace std;
int main()
{
	char str[256]=" Hello World";
	int fifo_write;
	
	fifo_write = open (" pipe_one ", O_WRONLY);
	if( fifo_write < 0)
	{
		cout<<"File is Not Opening"<<endl;
	}
	else{
		while(strcmp(str, "abort")!=0){
			cout<<"Enter Text:"<<endl;
			cin>>str;
			write(fifo_write, str , sizeof(str));
			cout<<"*"<<str"*"<<endl;
			
		}
	close(fifo_write);
	
	}
	
	return 0;
	

}

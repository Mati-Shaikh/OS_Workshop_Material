#include <unistd.h>
#include <iostream>
#include <sys/wait.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
using namespace std;
int main()
{
	int f1;
	f1 = mkfifo("pipe_one",0666);
		cout<<"Pipe Created"<<endl;
		char str[256]=" Hello World";
	int fifo_write;
	
	fifo_write = open("pipe_one",O_NONBLOCKING);
	if( fifo_write < 0)
	{
		cout<<"File is Not Opening"<<endl;
	}
	else{
		while(strcmp(str, "abort")!=0){
			cout<<"Enter Text"<<endl;
			cin>>str;
			write(fifo_write, str , sizeof(str));
			cout<<"*"<<str<<"*"<<endl;
			
		}
	close(fifo_write);
	
	}
	
	

	
	return 0;
	

}

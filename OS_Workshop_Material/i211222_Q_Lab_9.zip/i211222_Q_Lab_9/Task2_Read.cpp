#include <unistd.h>
#include <iostream>
#include <sys/wait.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
using namespace std;
int main()
{
	char str[256];
	int fifo_read;
	char message[100];
	
	fifo_read = open ("Pipe_2",O_RDONLY);
	
	if( fifo_read < 0)
	{
		cout<<"File is Not Opening"<<endl;
	}
	else{
		while(strcmp(str,"abort")!=0){
			
			read(fifo_read, str , sizeof(str));
			cout<<"Text:"<<str<<endl;
			cout<<"Enter Text From My Side:"<<endl;
		while (true) {
		int fd=open("Pipe_2" , O_WRONLY);
            	cin.getline(message, sizeof(message));
            	write(fd, message, strlen(message));
            	if (strcmp(message, "bye") == 0) {
                break;
            		}
			close(fd);
		}
	close(fifo_read);
	
	}
	}
	return 0;
	

}

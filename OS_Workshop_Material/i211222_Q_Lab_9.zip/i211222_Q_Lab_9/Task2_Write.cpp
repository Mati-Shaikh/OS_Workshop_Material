#include <unistd.h>
#include <iostream>
#include <sys/wait.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
using namespace std;
int main() {


   int f1;
	f1 = mkfifo("Pipe_2",0666);
	int f2;
	f2 = mkfifo("Pipe_3",0666);
	 char message[100];
	 char str[256];
	int fd=open("Pipe_2", O_WRONLY);
	
	
	if(f1<0)
	{
		cout<<"Pipe Not Created"<<endl;
	}
	
	else
	{
		cout<<"Pipe Created"<<endl;
		cout<<"Enter Text From Your Side:"<<endl;
		while (true) {
		
            		cin.getline(message, sizeof(message));
            		write(fd, message, strlen(message));
            		if (strcmp(message, "bye") == 0) {
                	break;
                while(strcmp(str,"abort")!=0){
			int fifo_read = open ("Pipe_2",O_RDONLY);
			read(fifo_read, str , sizeof(str));
			cout<<"Text:"<<str<<endl;
            		}
            		
	
	}
        }
	
	}
	
	return 0;
}

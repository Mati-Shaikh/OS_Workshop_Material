#include <unistd.h>
#include <iostream>
#include <sys/wait.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
using namespace std;
int main() {


   int f1;
	f1 = mkfifo("pipe_two",0666);
	
	
	if(f1<0)
	{
		cout<<"Pipe Not Created"<<endl;
	}
	
	else
	{
	
	
	
	}
	
	
	

    if (fork() == 0) {
        int fd = open(pipeName, O_WRONLY);
        char message[100];
        while (true) {
            std::cin.getline(message, sizeof(message));
            write(fd, message, strlen(message));
            if (strcmp(message, "bye") == 0) {
                break;
            }
        }
        close(fd);
        return 0;
    }

    int fd = open(pipeName, O_RDONLY);
    char message[100];
    while (true) {
        int bytesRead = read(fd, message, sizeof(message));
        if (bytesRead > 0) {
            message[bytesRead] = '\0';
            std::cout << "Received: " << message << std::endl;
            if (strcmp(message, "bye") == 0) {
                break;
            }
        }
    }
    close(fd);

    unlink(pipeName);

    return 0;
}


#include <unistd.h>
#include <iostream>
#include <sys/wait.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
using namespace std;
int main()
{
	char str[256]=" Hello World";
	int fifo_read;
	
	fifo_read = open ("pipe_one",O_RDONLY);
	if( fifo_read < 0)
	{
		cout<<"File is Not Opening"<<endl;
	}
	else{
		while(strcmp(str,"abort")!=0){
			
			read(fifo_read, str , sizeof(str));
			cout<<"Text:"<<str<<endl;
			
		}
	close(fifo_read);
	
	}
	
	return 0;
	

}

#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
using namespace std;
const int NUM_PHILOSOPHERS = 5;
sem_t forks[NUM_PHILOSOPHERS];
void* philosopher_problem(void*);

int main() {
    pthread_t philosophers[NUM_PHILOSOPHERS];
    int philosopher_ids[NUM_PHILOSOPHERS];
    int a=0,b=0,c=0,d=0;
    
    while(a < NUM_PHILOSOPHERS)
    {
    	 sem_init(&forks[a], 0, 1);
    	 a++;
    }
    
     while(b < NUM_PHILOSOPHERS)
    {
    	philosopher_ids[b] = b;
        pthread_create(&philosophers[b], NULL, philosopher_problem, &philosopher_ids[b]);
    	 b++;
    }
    
     while(c < NUM_PHILOSOPHERS)
    {
    	pthread_join(philosophers[c], NULL);
    	 c++;
    }
    
     while(d < NUM_PHILOSOPHERS)
    {
    	sem_destroy(&forks[d]);
    	 d++;
    }
    return 0;
}
void* philosopher_problem(void* num) {
    int id = *(int*)num;

    for (;true;) {
        cout << "Philosopher " << id << " is thinking." << endl;
        sleep(1);
      
        sem_wait(&forks[id]);
        sem_wait(&forks[(id + 1) % NUM_PHILOSOPHERS]); 
        
        cout << "Philosopher " << id << " is eating." << endl;
        sleep(1); 
       
        sem_post(&forks[id]); 
        sem_post(&forks[(id + 1) % NUM_PHILOSOPHERS]);

        cout << "Philosopher " << id << " finished eating and is thinking again." << endl;
    }

    return NULL;
}


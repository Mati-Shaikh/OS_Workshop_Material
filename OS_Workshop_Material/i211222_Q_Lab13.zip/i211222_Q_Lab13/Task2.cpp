#include <stdio.h>
#include <iostream>
#include <pthread.h>

#define MAX_ROWS 10
#define MAX_COLS 10

using namespace std;
struct ThreadData{
    int thread_id;
    int num_threads;
    int rows;
    int cols;
    int (*matrix_a)[MAX_COLS];
    int (*matrix_b)[MAX_COLS];
    int (*result)[MAX_COLS];
} ;


void *multiply(void *arg);
void printMatrix(int rows, int cols, int (*matrix)[MAX_COLS]);

int main() {
    int rows_a, cols_a, rows_b, cols_b;

    cout<<"Enter rows of Matrix A"<<endl;
    cin>>rows_a;
    
    cout<<"Enter Columns of Matrix A"<<endl;
    cin>>cols_a;
    
    cout<<"Enter rows of Matrix B"<<endl;
    cin>>rows_b;
    
    cout<<"Enter Columns of Matrix B"<<endl;
    cin>>cols_b;

    int matrix_a[MAX_ROWS][MAX_COLS];

    cout<<"Enter elements of matrix A: "<<endl;
    for (int i = 0; i < rows_a; ++i) {
        for (int j = 0; j < cols_a; ++j) {
            cin>>matrix_a[i][j];
        }
    }


    int matrix_b[MAX_ROWS][MAX_COLS];

    cout<<"Enter elements of matrix B: "<<endl;
    for (int i = 0; i < rows_b; ++i) {
        for (int j = 0; j < cols_b; ++j) {
            cin>>matrix_b[i][j];
        }
    }

    int result[MAX_ROWS][MAX_COLS];

    int num_threads = rows_a;

    
    ThreadData thread_data[num_threads];
    pthread_t threads[num_threads];

  
    for (int i = 0; i < num_threads; ++i) {
        thread_data[i].thread_id = i;
        thread_data[i].num_threads = num_threads;
        thread_data[i].rows = rows_a;
        thread_data[i].cols = cols_b;
        thread_data[i].matrix_a = matrix_a;
        thread_data[i].matrix_b = matrix_b;
        thread_data[i].result = result;

        pthread_create(&threads[i], NULL, multiply, (void *)&thread_data[i]);
    }

  
    for (int i = 0; i < num_threads; ++i) {
        pthread_join(threads[i], NULL);
    }

    cout<<"Result matrix C"<<endl;
    printMatrix(rows_a, cols_b, result);

    return 0;
}

void *multiply(void *arg) {
    ThreadData *data = (ThreadData *)arg;

    int rows_per_thread = data->rows / data->num_threads;
    int start_row = data->thread_id * rows_per_thread;
    int end_row = (data->thread_id == data->num_threads - 1) ? data->rows : start_row + rows_per_thread;

    for (int i = start_row; i < end_row; ++i) {
        for (int j = 0; j < data->cols; ++j) {
            data->result[i][j] = 0;
            for (int k = 0; k < data->cols; ++k) {
                data->result[i][j] += data->matrix_a[i][k] * data->matrix_b[k][j];
            }
        }
    }

    pthread_exit(NULL);
}

void printMatrix(int rows, int cols, int (*matrix)[MAX_COLS]) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
    }
}


#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
using namespace std;

int buffer[10];

int in = 0;
int out = 0;

pthread_mutex_t mutex;
sem_t full, e;

void insertItem(int item) {
    buffer[in] = item;
    in = (in + 1) % 10;
}

int removeItem() {
    int item = buffer[out];
    out = (out + 1) % 10;
    return item;
}

void *producer(void *arg) 
{
	int i=0;
	while(i<10)
   {
        int item = rand() % 100;
        sem_wait(&e);
        pthread_mutex_lock(&mutex);
        insertItem(item);
        cout<<"Item Produced : "<<item<<endl;
        sleep(0);
        pthread_mutex_unlock(&mutex);
        sem_post(&full);
        i++;
    }

    pthread_exit(NULL);
}

void *consumer(void *arg ) 
{
int i=0;
    while(i < 10) 
    {
        sem_wait(&full);
        pthread_mutex_lock(&mutex);
        int item = removeItem();
        cout<<"Items Consumed : "<<item<<endl;
        sleep(0);
        pthread_mutex_unlock(&mutex);
        sem_post(&e);
        i++;
    }

    pthread_exit(NULL);
}




int main() {
    pthread_mutex_init(&mutex, NULL);
    sem_init(&full, 0, 0);
    sem_init(&e, 0, 10);
    pthread_t producerThread, consumerThread;
    pthread_create(&producerThread, NULL, producer, NULL);
    pthread_create(&consumerThread, NULL, consumer, NULL);

    pthread_join(producerThread, NULL);
    pthread_join(consumerThread, NULL);

    pthread_mutex_destroy(&mutex);
    sem_destroy(&full);
    sem_destroy(&e);

    return 0;
}








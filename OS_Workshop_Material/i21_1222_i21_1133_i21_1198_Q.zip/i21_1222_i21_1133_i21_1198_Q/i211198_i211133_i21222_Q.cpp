#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <algorithm>

using namespace std;

// resources semaphores
sem_t cementSem, weatherSem;
sem_t oneDayShift;  // Semaphore to represent one day shift
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER; // for checking construction status
pthread_mutex_t consoleMutex = PTHREAD_MUTEX_INITIALIZER; // Mutex for console output

pthread_mutex_t wheelCart;

// Shared variable to signal that construction should be paused
bool pauseConstruction = false;




// Cost of 1 unit of each material;
int BRICK_COST=10;
int CEMENT_COST=400;
int CRUSH_COST= 20;
int SAND_COST=18;


// Shared variables
int availableBricks = 0;
int availableCement = 0;
int availableCrush = 0;
int availableSand = 0;
int availableElectricWires = 0;
int availableSeweragePipes = 0;
int availableWood = 0;
int availableSteel = 0;
int availableTools = 0;

// Worker information

class Worker {
public:
    string name;
    int dailyCost;
    string task;

    Worker(string name, int dailyCost, string task) {
        this->name = name;
        this->dailyCost = dailyCost;
        this->task = task;
    }
};

class Building {
    public:
        int givenBudget=0;
        string buildingType;
        int minDaysRequired;
        int bricksRequired;
        int cementRequired;
        int CrushRequired;
        int SandRequired;
        int ElectricWiresRequired;
        int SeweragePipesRequired;
        int WoodRequired;
        int SteelRequired;

    int calculateConstructionTime(int masons, int plumbers, int electricians, int carpenters) {
        int bricksUsedDaily = masons * 200;
        int cementUsedDaily = masons * 50;
        int crushUsedDaily = masons * 20;
        int sandUsedDaily = masons * 30;
        int steelUsedDaily = masons * 50;

        // Additional resources used by plumbers and electricians
        int pipesUsedDaily = SeweragePipesRequired / (plumbers * 80);
        int wiresUsedDaily = ElectricWiresRequired / (electricians * 100);
        int woodUsedDaily = WoodRequired / (carpenters * 100);

        // Calculate the minimum days required
        int daysBricks = bricksRequired / bricksUsedDaily;
        int daysCement = cementRequired / cementUsedDaily;
        int daysCrush = CrushRequired / crushUsedDaily;
        int daysSand = SandRequired / sandUsedDaily;
        int daysSteel = SteelRequired / steelUsedDaily;

        // Choose the maximum of these values as the minimum days required
        minDaysRequired = max({daysBricks, daysCement, daysCrush, daysSand, daysSteel});
        int d = max({pipesUsedDaily, wiresUsedDaily});

        minDaysRequired= minDaysRequired + d + woodUsedDaily;
        return minDaysRequired;
    }

};

class Residential : public Building {
    public:
        Residential() {
            buildingType = "Residential";
            minDaysRequired = 3; //30
            bricksRequired = 50;  //5000
            cementRequired = 30;  //2000
            CrushRequired = 200;   //1000
            SandRequired = 200;    //1500
            ElectricWiresRequired = 300;    //200
            SeweragePipesRequired = 300;    //100
            WoodRequired = 300;    // 3000
            SteelRequired = 200;    // 500
        }
};

class Commercial : public Building {
    public:
        Commercial() {
            buildingType = "Commercial";
            minDaysRequired = 6;
            bricksRequired = 100;
            cementRequired = 100;
            CrushRequired = 200;
            SandRequired = 300;
            ElectricWiresRequired = 500;
            SeweragePipesRequired = 300;
            WoodRequired = 500;
            SteelRequired = 100;
        }
};

class Industrial : public Building {
    public:
        Industrial() {
            buildingType = "Industrial";
            minDaysRequired = 90;
            bricksRequired = 15000;
            cementRequired = 8000;
            CrushRequired = 3000;
            SandRequired = 5000;
            ElectricWiresRequired = 800;
            SeweragePipesRequired = 500;
            WoodRequired = 8000;
            SteelRequired = 1500;
        }
};

// Building to make
Building* building;

// Function prototypes
void* waqt(void* arg);
void* bricklayer(void* arg);
void* cementMixer(void* arg);
void* constructionWorker(void* arg);
void* checkCompletion(void* arg);
int getMaterial(string);
void purchaseMaterial();
void printOutput(const string& output);
void* weatherSimulation(void* arg);

int main() {
    // Initialization
    //sem_init(&bricksSem, 0, 0);
    sem_init(&cementSem, 0, 1);
    sem_init(&weatherSem, 0, 1);
    sem_init(&oneDayShift, 0, 0);
    pthread_mutex_init(&wheelCart, NULL);

    // User input
    int buildingType;
    cout << "Choose building type: 1. Residential, 2. Commercial, 3. Industrial: ";
    cin >> buildingType;

    while(buildingType<1||buildingType>3){
        cout << "Enter valid option: ";
        cin >> buildingType;
    }

    // inializing object
    if (buildingType == 1)
        building = new Residential();
    else if (buildingType == 2)
        building = new Commercial();
    else
        building = new Industrial();

    int budget;
    cout << "Enter your budget: ";
    cin >> budget;

    int masons;
    cout << "How much masons you want to hire: ";
    cin >> masons;

    int plumbers;
    cout << "How much plumbers you want to hire: ";
    cin >> plumbers;

    int electrictions;
    cout << "How much electrictions you want to hire: ";
    cin >> electrictions;

    int carpenters;
    cout << "How much carpenters you want to hire: ";
    cin >> carpenters;

    // budget=10000;
    building->givenBudget=budget; //giving budget
    // masons=8;
    // electrictions=3;
    // plumbers=3;
    // carpenters=2;

    int days= building->calculateConstructionTime(masons, plumbers, electrictions, carpenters);

    cout << "Minimum days required to contruct the building is " << days << endl;

    purchaseMaterial();     // pruchasing material

    // starting work
    cout << "\n\n**** Work started ***\n\n";

    // thread for starting time checking Resources, weather
    pthread_t  timeThreadId=231, resourceCheckThreadId = 232, weatherThread=233;
    pthread_create(&timeThreadId, NULL, waqt, NULL);
    pthread_create(&resourceCheckThreadId, NULL, checkCompletion, NULL);
    pthread_create(&weatherThread, NULL, weatherSimulation, NULL);  // Simulate external factors like weather conditions


    // work simulated in loop
    int dayNo=0;
    do
    {
        dayNo++;
        sem_wait(&oneDayShift);
        
        printOutput("\n\nDay " + to_string(dayNo) +" constructon started\n");
        // worker threads ids
        pthread_t bricklayerThread[masons-3], cementMixerThread;

        // allocating workers
        // 1 worker is wheelCart worker
        building->givenBudget-=400;      // giving day pay to wheelcart worker
        
        // 2 workers to mix cement
        pthread_create(&cementMixerThread, NULL, cementMixer, NULL);
        
        // remaining workers to lay bricks
        for (int i = 4; i <= masons; i++) {
            Worker* w= new Worker("Worker"+ to_string(i), 500, "brick laying");
            pthread_create(&bricklayerThread[i], NULL, bricklayer, static_cast<void*>(w));
        }

        for (int i = 4; i <= masons; i++) {
            pthread_join(bricklayerThread[i], NULL);
        }
        
        pthread_join(cementMixerThread, NULL);
            
    } while (sem_trywait(&oneDayShift) != 0);   // Continue every time a day ends 
    

    // Cleanup
    sem_destroy(&cementSem);
    sem_destroy(&weatherSem);

    return 0;
}

void purchaseMaterial()
{
    // initial budget should be atleast 5360+3700
    // purchasing initial items to start construction
    availableBricks=100;
    availableCement=10;
    availableSand = 20;
    
    // paying bill
    int bill=((availableBricks*BRICK_COST)+(availableCement*CEMENT_COST)+(availableSand* SAND_COST));
    cout << "Material Purchasine Bill: " << bill << endl;
    if(bill>building->givenBudget)
    {
        int a;
        cout << "Add more budget to purchase material: ";
        cin >> a;
        building->givenBudget+=a;
    }
    
    building->givenBudget-= bill;
    cout << "Remainng budget: " << building->givenBudget;

    // if after purchasing budget gets less than 3700 (day pay of all workers);
    if(building->givenBudget<=3700)
    {
        int a;
        cout << "Add more budget to pay workers and start construction: ";
        cin >> a;
        building->givenBudget+=a;
    }
}
void* weatherSimulation(void* arg) {
    while (true) {
        // Generate a random number between 1 and 10
        int randomNum = rand() % 10 + 1;

        if (randomNum == 4) {
            printOutput("\n\nIt's raining lightly, work stopped for this day.\n");

        } else if (randomNum == 5) {
            printOutput("\n\nRain is very intense, work stopped for this day.\n");

            sem_post(&weatherSem);
        }

        // Sleep for 10 seconds
        sleep(10);
    }

    return nullptr;
}

void printOutput(const string& output) 
{
    pthread_mutex_lock(&consoleMutex);
    cout << output << endl;
    pthread_mutex_unlock(&consoleMutex);
}

void* bricklayer(void* args) {
    Worker* worker = (Worker*)args;

    building->givenBudget -= worker->dailyCost;   // giving day pay

    int plaster = 0;
    int bricks = 0;

    while (sem_trywait(&oneDayShift) != 0) {
        if(sem_trywait(&weatherSem)!=0) {

            if (rand() % 10 + 1 == 5) {
                printOutput(worker->name + " is taking a whole day break due to sickness.");
                printOutput("Swapping worker with a new one.");
                pthread_t w=235;
                Worker* n = new Worker("Swapped Mason",200,"brick laying");
                pthread_create(&w, NULL, bricklayer, static_cast<void*>(n));
                pthread_exit(NULL);
            }

            if (bricks < 2) {
                printOutput(worker->name + " waiting for bricks...");
                bricks = getMaterial("bricks");
            }

            if (plaster < 1) {
                printOutput(worker->name + " waiting for plaster...");
                plaster = getMaterial("plaster");
            }

            printOutput(worker->name + " " + worker->task);
            building->bricksRequired -= 2;

            plaster -= 1;
            bricks -= 2;

            sleep(2);
        }
        else{
            pthread_exit(NULL);
        }
    }

    printOutput("\nMason " + worker->name+ "'s Shift ended for this day.\n");
    pthread_exit(NULL);
}

void* cementMixer(void* arg) 
{
    building->givenBudget-=400*2;      // giving day pay to two workers
    
    while (sem_trywait(&oneDayShift) != 0) {
        if(sem_trywait(&weatherSem)!=0) {
            if (rand() % 10 + 1 == 5) {
                printOutput("Worker2 and Worker3 is taking a whole day break due to sickness.");
                printOutput("Swapping worker with a new pair.");
                pthread_t w=236;
                Worker* n = new Worker("Swapped Cement Worker",200,"brick laying");
                pthread_create(&w, NULL, cementMixer, static_cast<void*>(n));
                pthread_exit(NULL);
            }

            sem_wait(&cementSem);

            if (availableCement == 0) {
                int a;
                printOutput("Cement ran out (" + to_string(availableCement) + ")");
                printOutput("Worker 2 and 3 waiting for cement...");

                pthread_mutex_lock(&consoleMutex);
                cout << "Add more budget to buy cement (" + to_string(CEMENT_COST) + "): ";
                cin >> a;
                while (a < CEMENT_COST) {
                    cout << "Enter more budget to buy Cement : ";
                    cin >> a;
                }
                availableCement += a / CEMENT_COST;
                pthread_mutex_unlock(&consoleMutex);
            }

            if (availableSand <= 10) {
                int a;
                printOutput("Sand ran out (" + to_string(availableSand) + ")");
                printOutput("Worker 2 and 3 waiting for Sand...");

                pthread_mutex_lock(&consoleMutex);
                cout << "Add more budget to buy Sand (" + to_string(SAND_COST) + "): ";
                cin >> a;
                while (a < SAND_COST) {
                    cout << "Enter more budget to buy Sand : ";
                    cin >> a;
                }
                availableSand += a / SAND_COST;
                pthread_mutex_unlock(&consoleMutex);
            }

            availableCement--;
            availableSand -= 10;
            building->cementRequired--;
            building->SandRequired -= 10;
            printOutput("Worker 2 and 3 completed 1 unit of cement mixing");
            printOutput("Cement-> required: " + to_string(building->cementRequired) + " , available: " + to_string(availableCement));
        }
        else{
            printOutput("exiting");
            pthread_exit(NULL);
        }
    }

    sem_post(&cementSem);

    printOutput("\n\nCement workers' Shift ended for this day.\n");
    pthread_exit(NULL);
}


int getMaterial(string work)
{
    if(sem_trywait(&weatherSem)!=0) {
        printOutput("Worker1 delivering " + work); 
        int material;
        pthread_mutex_lock(&wheelCart);
        if(work == "plaster")
        {
            sem_post(&cementSem); // Release the permit to make cement plaster
            material = 10;
        }
        else
        {
            // ran out of bricks
            if(availableBricks==0)
            {
                int a;
                printOutput("Bricks ran out (" + to_string(availableBricks) + ")");
                printOutput("Wheel Cart Worker waiting for bricks...");

                pthread_mutex_lock(&consoleMutex);
                cout << "Add more budget to buy bricks (" + to_string(BRICK_COST) +"): ";
                cin >> a;
                while (a<BRICK_COST)
                {
                    cout << "Enter more budget to buy bricks : ";
                    cin >> a;
                }
                availableBricks+=a/BRICK_COST;  // amount of new bricks units purchased
                pthread_mutex_unlock(&consoleMutex);
            }

            if(availableBricks<20)
            {
                material=availableBricks;
            }
            else
            {
                material= 20;
            }
            availableBricks-=material;
        }
        pthread_mutex_unlock(&wheelCart);

        return material;
    }
    else{
            pthread_exit(NULL);
    }
}

void* checkCompletion(void* arg) {
    while (1) {
        pthread_mutex_lock(&mutex); // Ensure mutual exclusion when checking and updating construction status

        if (building->bricksRequired <= 0 || building->cementRequired <= 0 || building->SandRequired <= 0) {
            printOutput("\n\n\n*** Buiding finised ***\n\n");
            exit(EXIT_SUCCESS);
        }

        pthread_mutex_unlock(&mutex);
    }
}

void* waqt(void* arg) {
    while(1){
        // Unlock the semaphore
        sem_post(&oneDayShift);

        // Simulate work for 1 minute (60 seconds)
        sleep(3);

        // Lock the semaphore
        sem_wait(&oneDayShift);
    }

    // Thread finishes
    pthread_exit(NULL);
}
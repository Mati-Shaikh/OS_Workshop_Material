#include <iostream>
#include <pthread.h>
using namespace std;

const int NUM_THREADS = 2;

struct ThreadArgs {
    int startRow;
    int endRow;
    int** A;
    int** B;
    int** C;
    int matrixSize;
};

void* multiply(void* args) {
    ThreadArgs* threadArgs = static_cast<ThreadArgs*>(args);
    int startRow = threadArgs->startRow;
    int endRow = threadArgs->endRow;
    int** A = threadArgs->A;
    int** B = threadArgs->B;
    int** C = threadArgs->C;
    int matrixSize = threadArgs->matrixSize;

    int i = startRow;
    while (i < endRow) {
        int j = 0;
        while (j < matrixSize) {
            C[i][j] = 0;
            int k = 0;
            while (k < matrixSize) {
                C[i][j] += A[i][k] * B[k][j];
                ++k;
            }
            ++j;
        }
        ++i;
    }

    delete threadArgs; // Don't forget to clean up the dynamically allocated arguments
    pthread_exit(nullptr);
}

int main() {
    int size;
    cout << "Enter the size of matrices: ";
    cin >> size;

    int** A = new int*[size];
    int** B = new int*[size];
    int** C = new int*[size];

    for (int i = 0; i < size; ++i) {
        A[i] = new int[size];
        B[i] = new int[size];
        C[i] = new int[size];
    }

    cout << "Enter elements of matrix A:" << endl;
    int i = 0;
    while (i < size) {
        int j = 0;
        while (j < size) {
            cin >> A[i][j];
            ++j;
        }
        ++i;
    }

    cout << "Enter elements of matrix B:" << endl;
    i = 0;
    while (i < size) {
        int j = 0;
        while (j < size) {
            cin >> B[i][j];
            ++j;
        }
        ++i;
    }

    pthread_t threads[NUM_THREADS];
    int rowsPerThread = size / NUM_THREADS;
    int startRow = 0;

    i = 0;
    while (i < NUM_THREADS) {
        int endRow;
        if (i == NUM_THREADS - 1) {
            endRow = size;
        } else {
            endRow = startRow + rowsPerThread;
        }

        ThreadArgs* args = new ThreadArgs{startRow, endRow, A, B, C, size};
        pthread_create(&threads[i], nullptr, multiply, static_cast<void*>(args));
        startRow = endRow;
        ++i;
    }

    i = 0;
    while (i < NUM_THREADS) {
        pthread_join(threads[i], nullptr);
        ++i;
    }

    cout << "After Multiplication matrix C:" << endl;
    i = 0;
    while (i < size) {
        int j = 0;
        while (j < size) {
            cout << C[i][j] << " ";
            ++j;
        }
        cout << endl;
        ++i;
    }

    for (int i = 0; i < size; ++i) {
        delete[] A[i];
        delete[] B[i];
        delete[] C[i];
    }
    delete[] A;
    delete[] B;
    delete[] C;

    return 0;
}


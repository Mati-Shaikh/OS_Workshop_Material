#include <iostream>
#include <cmath>
#include <pthread.h>

using namespace std;

struct MultiplyParams {
    int startRow;
    int endRow;
    float* weights;
    float* features;
    float* result;
    int numRows;
    int numCols;
};

struct AddBiasesParams {
    int startRow;
    int endRow;
    float* result;
    float* biases;
};

struct ApplySigmoidParams {
    int startRow;
    int endRow;
    float* result;
};

float customSigmoid(float x) {
    return 1.0 / (1.0 + exp(-x));
}

void* customMultiplyMatrix(void* params) {
    MultiplyParams* multiplyParams = static_cast<MultiplyParams*>(params);

    int i = multiplyParams->startRow;
    while (i < multiplyParams->endRow) {
        multiplyParams->result[i] = 0;
        int j = 0;
        while (j < multiplyParams->numCols) {
            multiplyParams->result[i] += multiplyParams->weights[i * multiplyParams->numCols + j] * multiplyParams->features[j];
            ++j;
        }
        ++i;
    }

    return nullptr;
}

void* customAddBiases(void* params) {
    AddBiasesParams* addBiasesParams = static_cast<AddBiasesParams*>(params);

    int i = addBiasesParams->startRow;
    while (i < addBiasesParams->endRow) {
        addBiasesParams->result[i] += addBiasesParams->biases[i];
        ++i;
    }

    return nullptr;
}

void* customApplySigmoid(void* params) {
    ApplySigmoidParams* applySigmoidParams = static_cast<ApplySigmoidParams*>(params);

    int i = applySigmoidParams->startRow;
    while (i < applySigmoidParams->endRow) {
        applySigmoidParams->result[i] = customSigmoid(applySigmoidParams->result[i]);
        ++i;
    }

    return nullptr;
}

int main() {
    int numFeatures, numHiddenNeurons;
    cout << "Enter Number of features: ";
    cin >> numFeatures;
    cout << "Enter Number of hidden neurons: ";
    cin >> numHiddenNeurons;

    float weights[numHiddenNeurons * numFeatures];
    float features[numFeatures];
    float biases[numHiddenNeurons];
    float Z[numHiddenNeurons];

    cout << "Enter the weight matrix W:" << endl;
    int i = 0;
    while (i < numHiddenNeurons) {
        int j = 0;
        while (j < numFeatures) {
            cin >> weights[i * numFeatures + j];
            ++j;
        }
        ++i;
    }

    cout << "Enter the features matrix xi:" << endl;
    i = 0;
    while (i < numFeatures) {
        cin >> features[i];
        ++i;
    }

    cout << "Enter the biases matrix b:" << endl;
    i = 0;
    while (i < numHiddenNeurons) {
        cin >> biases[i];
        ++i;
    }

    // Parameters for thread functions
    MultiplyParams multiplyParams[numHiddenNeurons];
    AddBiasesParams addBiasesParams[numHiddenNeurons];
    ApplySigmoidParams applySigmoidParams[numHiddenNeurons];

    // Create threads
    i = 0;
    while (i < numHiddenNeurons) {
        multiplyParams[i] = {i, i + 1, weights, features, Z, numHiddenNeurons, numFeatures};
        pthread_t thread;
        pthread_create(&thread, nullptr, customMultiplyMatrix, &multiplyParams[i]);
        pthread_join(thread, nullptr);
        ++i;
    }

    // Create threads
    i = 0;
    while (i < numHiddenNeurons) {
        addBiasesParams[i] = {i, i + 1, Z, biases};
        pthread_t thread;
        pthread_create(&thread, nullptr, customAddBiases, &addBiasesParams[i]);
        pthread_join(thread, nullptr);
        ++i;
    }

    // Create threads for sigmoid function application
    i = 0;
    while (i < numHiddenNeurons) {
        applySigmoidParams[i] = {i, i + 1, Z};
        pthread_t thread;
        pthread_create(&thread, nullptr, customApplySigmoid, &applySigmoidParams[i]);
        pthread_join(thread, nullptr);
        ++i;
    }

    // Print the result matrix Z
    cout << "Result matrix Z:" << endl;
    i = 0;
    while (i < numHiddenNeurons) {
        cout << Z[i] << " ";
        ++i;
    }
    cout << endl;

    return 0;
}


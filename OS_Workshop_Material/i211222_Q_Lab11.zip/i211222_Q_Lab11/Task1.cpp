#include <iostream>
#include <pthread.h>
#include <chrono>
#include <unistd.h>
using namespace std;

const int group_Per_thread = 4;

void* behavior_Of_threads(void* arg) {
    int threadNumber = *(static_cast<int*>(arg));
    sleep(1);
    cout << "I am thread No. " << threadNumber << " with the thread id: " << pthread_self() << "." << endl;
    return nullptr;
}

int main() {
    int input;
    cout << "Enter Number of threads: ";
    cin >> input;

    pthread_t threads[input];

    int i = 1;
    // Using chrono library to check the time of every thread creation
    while (i <= input) {
        int* threadNumber = new int(i);
        pthread_create(&threads[i - 1], nullptr, behavior_Of_threads, static_cast<void*>(threadNumber));
        usleep(100 * 1000);
        ++i;
    }

    int numGroups = (input + group_Per_thread - 1) / group_Per_thread;

    int group = 1;
    while (group <= numGroups) {
        cout << "After " << group << " second(s)" << endl;

        int i = (group - 1) * group_Per_thread;
        while (i < group * group_Per_thread && i < input) {
            void* result;
            pthread_join(threads[i], &result);
            ++i;
        }

        usleep(100 * 1000);
        ++group;
    }

    cout << "Main was waiting for the threads and is now terminating." << endl;

    return 0;
}


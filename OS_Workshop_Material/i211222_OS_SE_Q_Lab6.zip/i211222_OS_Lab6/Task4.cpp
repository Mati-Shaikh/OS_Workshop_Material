#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

using namespace std;

int main() {
char message[100];
  // Create a pipe
  int pipe_fd[2];
  int pipe_fd2[2];
  pipe(pipe_fd);
  pipe(pipe_fd2);
  // Create a child process
  pid_t pid = fork();

  // If the child process
  if (pid == 0) {
    // Close the write end of the pipe
    close(pipe_fd[1]);
    
    while (true) {
      read(pipe_fd2[0], message, sizeof(message));

      // If the message is "bye", stop the communication
      if (strcmp(message, "bye") == 0) {
        break;
      }

      cout << "Received message from parent: " << message << endl;
    }
    close(pipe_fd[0]);
    exit(0);
  }


  if (pid > 0) {
    // Close the read end of the pipe
    close(pipe_fd[0]);

    char message[100];
    cout << "Enter a message for the child: ";
    cin.getline(message, sizeof(message));
    write(pipe_fd2[1], message, sizeof(message));

    // Wait for the child process to terminate
    waitpid(pid, NULL, 0);

    // Close the write end of the pipe
    close(pipe_fd2[1]);
  }

  return 0;
}


#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int main() {
  // Create a pipe with a capacity of 10 elements
  int pipe_fd[2];
  pipe(pipe_fd);

  // Fork two child processes
  pid_t pids[2];
  pids[0] = fork();
  pids[1] = fork();

  // Producer process
  if (pids[0] == 0) {
    for (int i = 0; i < 20; i++) {
      // Write to the pipe
      write(pipe_fd[1], &i, sizeof(int));
      cout<<"Producer Writing"<<endl;
    }
    exit(0);
  }

  // Consumer process
  if (pids[1] == 0) {
    for (int i = 0; i < 10; i++) {
      // Read from the pipe
      int data;
      read(pipe_fd[0], &data, sizeof(int));
      cout <<"Read Consumer Process: "<< data << endl;
    }
    exit(0);
  }

  // Wait for both child processes to finish
  waitpid(pids[0], NULL, 0);
  waitpid(pids[1], NULL, 0);

  // Close the pipe file descriptors
  close(pipe_fd[0]);
  close(pipe_fd[1]);

  return 0;
}


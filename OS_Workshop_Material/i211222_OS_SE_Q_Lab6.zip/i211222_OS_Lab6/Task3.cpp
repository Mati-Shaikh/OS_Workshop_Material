#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

void merge_sort(int* array, int start, int end) {
  if (start < end) {
    int mid = (start + end) / 2;

    // Create a pipe
    int pipe_fd[2];
    pipe(pipe_fd);

    // Fork two child processes
    pid_t pids[2];
    pids[0] = fork();
    pids[1] = fork();

    // Sort the left subarray
    if (pids[0] == 0) {
      merge_sort(array, start, mid);
      close(pipe_fd[1]);
      for (int i = start; i <= mid; i++) {
        write(pipe_fd[0], &array[i], sizeof(int));
      }
      close(pipe_fd[0]);
      exit(0);
    }

    // Write the sorted right subarray to the pipe
    if (pids[1] == 0) {
      merge_sort(array, mid + 1, end);
      close(pipe_fd[0]);
      for (int i = mid + 1; i <= end; i++) {
        write(pipe_fd[1], &array[i], sizeof(int));
      }
      close(pipe_fd[1]);
      exit(0);
    }

    // Wait for both child processes to finish
    waitpid(pids[0], NULL, 0);
    waitpid(pids[1], NULL, 0);

    // Merge the sorted subarrays from the pipe
    int sorted_array[end - start + 1];
    int i = 0;
    int j = 0;
    int k = 0;
    while (i < pipe_fd[0] && j < pipe_fd[1]) {
      if (array[i] < array[j]) {
        sorted_array[k++] = array[i++];
      } else {
        sorted_array[k++] = array[j++];
      }
    }

    // Copy the remaining elements from the left subarray to the sorted array
    while (i < pipe_fd[0]) {
      sorted_array[k++] = array[i++];
    }

    // Copy the remaining elements from the right subarray to the sorted array
    while (j < pipe_fd[1]) {
      sorted_array[k++] = array[j++];
    }

    // Copy the sorted array back to the original array
    for (int i = 0; i < end - start + 1; i++) {
      array[start + i] = sorted_array[i];
    }

    // Close the pipe file descriptors
    close(pipe_fd[0]);
    close(pipe_fd[1]);
  }
}

int main() {
  // Create an array of integers
  int array[] = {5, 3, 2, 1, 4};

  // Sort the array using merge sort
  merge_sort(array, 0, sizeof(array) / sizeof(array[0]) - 1);

  // Print the sorted array
  for (int i = 0; i < sizeof(array) / sizeof(array[0]); i++) {
    cout << array[i] << " ";
  }
  cout << endl;

  return 0;
}


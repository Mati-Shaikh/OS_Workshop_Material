#include <iostream>
#include <sys/time.h>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

struct ProcessInfo {
  time_t start_time;
  time_t end_time;
  double cpu_usage;
};

void monitor_process(int pipe_fd) {
  // Get the start time
  time_t start_time = time(NULL);

  // Do some work
  sleep(1);

  // Get the end time
  time_t end_time = time(NULL);

  // Calculate the CPU usage
  double cpu_usage = (end_time - start_time) * 100.0 / sysconf(_SC_CLK_TCK);

  // Write the process information to the pipe
  write(pipe_fd, &cpu_usage, sizeof(double));

  // Print the start and end process times
  cout << "Process start time: " << start_time << endl;
  cout << "Process end time: " << end_time << endl;
}

int main() {
  // Create a pipe
  int pipe_fd[2];
  pipe(pipe_fd);

  // Launch multiple child processes
  for (int i = 0; i < 10; i++) {
    pid_t pid = fork();

    if (pid == 0) {
      // Monitor the process
      monitor_process(pipe_fd[1]);
      exit(0);
    }
  }

  // Close the write end of the pipe
  close(pipe_fd[1]);

  // Read the process information from the pipe
  double cpu_usage[10];
  time_t start_time[10], end_time[10];
  for (int i = 0; i < 10; i++) {
    read(pipe_fd[0], &cpu_usage[i], sizeof(double));
    read(pipe_fd[0], &start_time[i], sizeof(time_t));
    read(pipe_fd[0], &end_time[i], sizeof(time_t));
  }

  // Close the read end of the pipe
  close(pipe_fd[0]);

  // Find the most CPU bound process
  int most_cpu_bound_process = 0;
  double max_cpu_usage = cpu_usage[0];
  for (int i = 1; i < 10; i++) {
    if (cpu_usage[i] > max_cpu_usage) {
      most_cpu_bound_process = i;
      max_cpu_usage = cpu_usage[i];
    }
  }

  // Print the process information
  cout << "Process information:" << endl;
  for (int i = 0; i < 10; i++) {
    cout << "Process " << i << " CPU usage: " << cpu_usage[i] << ", Start time: " << start_time[i] << ", End time: " << end_time[i] << endl;
  }

  // Print the most CPU bound process
  cout << "Most CPU bound process: " << most_cpu_bound_process << endl;

  return 0;
}


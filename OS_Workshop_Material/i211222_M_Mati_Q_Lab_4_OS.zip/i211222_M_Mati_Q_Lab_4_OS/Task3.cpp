#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

// Function to check for terminated child processes
bool check_terminated_child_processes(pid_t* children, int num_children) {
  // Iterate over the child processes
  for (int i = 0; i < num_children; i++) {
    // Check if the child process has terminated
    int status;
    pid_t pid = waitpid(children[i], &status, WNOHANG);

    // If the child process has terminated, print its PID and remove it from the list of children
    if (pid != 0) {
      cout << "Child process {pid} terminated" << endl;
      children[i] = children[num_children - 1];
      num_children--;
      return true;
    }
  }

  // If no child processes have terminated, return false
  return false;
}

int main() {
  // Number of child processes
  int num_children = 3;

  // Create an array to store the PIDs of the child processes
  pid_t* children = new pid_t[num_children];

  // Create the child processes
  for (int i = 0; i < num_children; i++) {
    pid_t pid = fork();
    if (pid == 0) {
      // Child process code
      cout << "Child process {getpid()} started" << endl;
      sleep(i);
      cout << "Child process {getpid()} finished" << endl;
      exit(0);
    } else {
      // Parent process code
      children[i] = pid;
    }
  }

  // While the parent process is waiting for child processes to terminate, continue working
  while (true) {
    // Check for terminated child processes
    if (check_terminated_child_processes(children, num_children)) {
      // At least one child process has terminated, continue working
      // ...
    } else {
      // No child processes have terminated, wait for a while
      sleep(1);
    }

    // If all child processes have terminated, break out of the loop
    if (num_children == 0) {
      break;
    }
  }

  // Delete the array of child process PIDs
  delete[] children;

  return 0;
}


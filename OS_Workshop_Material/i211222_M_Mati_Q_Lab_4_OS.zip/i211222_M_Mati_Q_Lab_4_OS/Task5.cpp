#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;
int NUM_RESOURCES = 10;

int REQUEST = 5;

void allocate_resources(pid_t pid) {
  if (NUM_RESOURCES >= REQUEST) {
   
    NUM_RESOURCES -= REQUEST;
    cout << "Allocated {REQUEST} resources to child process {pid}" << endl;
  } else {
    cout << "Child process {pid} waiting for resources" << endl;
    wait(NULL);
  }
}

void deallocate_resources(pid_t pid) {
  NUM_RESOURCES += REQUEST;
  cout << "Deallocated {REQUEST} resources from child process {pid}" << endl;
}

int main() {

  pid_t pid = fork();
  if (pid == 0) {
    allocate_resources(pid);
  }

  else {
    wait(NULL);
    deallocate_resources(pid);
  }

  return 0;
}



#include <iostream>
#include <unistd.h>

using namespace std;

int main() {
  pid_t pid = fork();

  if (pid == 0) {
    exit(0);
  }

  else {
    sleep(1);
  }

  return 0;
}

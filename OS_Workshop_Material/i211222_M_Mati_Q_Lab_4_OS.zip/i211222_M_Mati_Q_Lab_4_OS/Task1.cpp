#include <iostream>
#include <unistd.h>
using namespace std;
pid_t pid;
int main()
{
  pid=fork();
 if(pid==0)//c1
 {
 	pid_t var=getppid();
 	pid_t pid_1=fork();
 	if(pid_1==0)//c3
 	{
 		pid_t pid_2=fork();
 		if(pid_2==0)//c5
 		{
 			pid_t pid_3=fork();
 			if(pid_3==0)//c6
 			{
 			}
 			else
 			{
 				//cout<<"c7"<<endl;
 				cout<<"The Id of this C7 child's Parent is : "<<var<<endl;
 			}
 		}
 		else
 		{
 		}
 	}
 	else
 	{
 	}
 	}
 else
 {
 }

 
pid_t pid2=fork();
if(pid2==0)
{
	pid2=fork();	
	if(pid2==0)
	{
	}
	else
	{
	}
}
else
{
}
 
 
 return 0;
}


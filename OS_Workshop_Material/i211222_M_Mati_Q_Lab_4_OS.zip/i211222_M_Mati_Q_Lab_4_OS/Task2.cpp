#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
using namespace std;

int main() {
    const int numProcesses = 5;
    int childStatus;

    for (int i = 0; i < numProcesses; ++i) {
        pid_t pid = fork();

        if (pid == 0) {
           
            if (i % 2 == 0) {
                cout << "Child " << getpid() << " (Success) exiting." << std::endl;
                exit(0);
            } else {
    
                cout << "Child " << getpid() << " (Failure) exiting." << std::endl;
                exit(1);
            }
        } else if (pid < 0) {
            
            cout << "Error forking process." << endl;
            return 1;
        }
    }


    for (int i = 0; i < numProcesses; ++i) {
        pid_t childPid = wait(&childStatus);
        if (WIFEXITED(childStatus)) {
            int exitCode = WEXITSTATUS(childStatus);
            cout << "Child " << childPid << " exited with status code: " << exitCode << endl;
        }
    }

    return 0;
}


#include <iostream>
#include <fstream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
using namespace std;

int main() {
    // Open a file for writing in the parent process
    ofstream file("example.txt");
    if (!file.is_open()) {
        cout << "Failed to open file." << endl;
        return 1;
    }

    file << "This is a test." << endl;
    file.close();

    // Create a child process
    pid_t child_pid = fork();

    if (child_pid == 0) {
        ifstream child_file("example.txt");
        if (!child_file.is_open()) {
            cout << "Child process failed to open the file." << endl;
            exit(1);
        }

        string line;
        while (getline(child_file, line)) {
            cout << "Child process read: " << line << endl;
        }

        child_file.close();
        exit(0);
    } else {
        int status;
        if (waitpid(child_pid, &status, 0) == -1) {
            cout << "Waitpid failed." << endl;
            return 1;
        }

        cout << "Parent process: Child process exited with status " << status << endl;
    }

    return 0;
}


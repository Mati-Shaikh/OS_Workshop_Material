#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
using namespace std;

int main(int argc, char *argv[]) {

	if (argc != 3) {
        cout << "Usage: " << argv[0] << " <input> <output>\n";
    }

    // Create a child process
    pid_t child_pid = fork();


    if (child_pid == 0) {
    execl("hello",NULL);
    cout<<"Error in the Executable command"<<endl;
       
      
    } else {
    
    	pid_t child_pid2=fork();
    	
    	if(child_pid2==0)
    	{
    		  if (execl("/bin/cp", "cp", argv[1], argv[2], (char *)nullptr)) {
            perror("execl");
            exit(1);
        }
    	}
    	
    	
        
    }

    return 0;
}


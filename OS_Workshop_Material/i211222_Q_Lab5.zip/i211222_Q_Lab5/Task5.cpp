#include <iostream>
#include <unistd.h>
using namespace std;


int main() {
   char ∗env[]= {"export TERM=vt100","PATH=/bin:/usr/bin", NULL} ;
char ∗args[]= {"cat","f1",NULL} ;
execve ("/bin/cat",args,env);
}


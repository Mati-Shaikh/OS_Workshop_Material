#include <iostream>
#include <cstdlib>

int main() {
    // Command to be executed
    const char* command = "ls"; // Replace with your desired command

    // Execute the command
    int exitCode = std::system(command);

    if (exitCode == 0) {
        std::cout << "Command executed successfully." << std::endl;
    } else {
        std::cerr << "Command failed with exit code " << exitCode << std::endl;
    }

    return 0;
}


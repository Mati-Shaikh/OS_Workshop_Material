#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
using namespace std;

int main() {

	cout<<"Your List of Directory Files:"<<endl;
    execl("/bin/ls", "ls","-l",NULL);
   	cout<<"Error"<<endl;
    

    return 0;
}



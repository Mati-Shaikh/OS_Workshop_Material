#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t child1_pid, child2_pid;
    int status1, status2;

    child1_pid = fork();

    if (child1_pid == 0) {
        std::cout << "Child 1 executing program A" << std::endl;
        execl("/path/to/programA", "programA", (char*)nullptr);
        perror("execl for child 1");
        return 1;
    }

    child2_pid = fork();

    if (child2_pid == 0) {
        // This code is executed by the second child process
        std::cout << "Child 2 executing program B" << std::endl;
        execl("/path/to/programB", "programB", (char*)nullptr);
        perror("execl for child 2");
        return 1;
    }

    // This code is executed by the parent process

    // Wait for both child processes to complete
    waitpid(child1_pid, &status1, 0);
    waitpid(child2_pid, &status2, 0);

    if (WIFEXITED(status1)) {
        std::cout << "Child 1 exited with status " << WEXITSTATUS(status1) << std::endl;
    }

    if (WIFEXITED(status2)) {
        std::cout << "Child 2 exited with status " << WEXITSTATUS(status2) << std::endl;
    }

    return 0;
}

